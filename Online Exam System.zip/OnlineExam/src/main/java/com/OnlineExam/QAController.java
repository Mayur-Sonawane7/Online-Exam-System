package com.OnlineExam;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class QAController {
	
	
	@Autowired
	SessionFactory factory;
		
	@GetMapping("answer/{id}")
	public String getAnswer1(@PathVariable int id) 
	{
		
		Session session=factory.openSession();
		
		Answer answer=session.load(Answer.class, id);
		
		System.out.println(answer);
		
		// createSQLQuery method accepts SQL query and execute that query . In Hibernate we generally execute HQL queries , but using below method we can execute SQL query also
				
		NativeQuery<Object[]> query=session.createSQLQuery("select answer_id , answer , question.question_id,question from question , answer where question.question_id=answer.question_id and answer_id="+id);
				
		List<Object[]> list = query.list(); 
		
		// list [ (array having 4 values) only this single array is present in list ] 
		
		System.out.println(list.size());
		
		Object[] array=list.get(0);
		
		return Arrays.toString(array); 
		
		// java.util.Arrays class contains toString() which gives content of array
		
		
//		StringBuffer sb=new StringBuffer("");

//		for (Object[] array : list) 
//		{
//				for(Object obj:array)
//				{
//					sb.append(obj+",");
//					System.out.println(obj);
//				}
//
//		}
				
	//	return sb.toString();
	
	}

	@GetMapping("question/{id}")
	public Question getQuestion(@PathVariable int id)
	{

		Session session=factory.openSession();
	
		Question question=session.load(Question.class, id);	
		
		List<Answer> answers=question.getAnswers();
		
		System.err.println(question);
		
		return question;
		
	}
	
	/*@GetMapping("answers/{id}")
	public String getAnswer(@PathVariable int id) 
	{
		Session session=factory.openSession();
		Answer answer=session.load(Answer.class, id);
		
		Query query=session.createQuery("select question.questionid , question.question , answer.answerid,answer.answer from Question question join Answer answer on answer.answerid="+id);
		List<Object[]> list = query.list();
		
		for (Object[] o : list) 
		{
			for(Object obj:o)
			System.err.println(obj);
		}
		return "rrr";
	}*/
}
