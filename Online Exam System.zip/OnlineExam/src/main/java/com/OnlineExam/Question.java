package com.OnlineExam;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Question {
	@Id
	@Column(name = "question_id")
	private int questionid;
	private String question;
	@OneToMany (targetEntity = Answer.class,cascade = CascadeType.ALL)
	@JoinColumn(name="question_id")
	private List<Answer> answers;
				
	public Question() {
		super();

	}
	public Question(int questionid, String question, List<Answer> answers) {
		super();
		this.questionid = questionid;
		this.question = question;
		this.answers = answers;
	}
	public int getQuestionid() {
		return questionid;
	}
	public void setQuestionid(int questionid) {
		this.questionid = questionid;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public List<Answer> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}
	@Override
	public String toString() {
		return "Question [questionid=" + questionid + ", question=" + question + ", answers=" + answers + "]";
	}
	
	
}
